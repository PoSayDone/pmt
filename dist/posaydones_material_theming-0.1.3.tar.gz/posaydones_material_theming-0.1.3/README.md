Small gui + cli app for managing your colorscheme using material color utilities
